package com.lanchenlayer.controllers;

import com.lanchenlayer.entities.Produto;
import com.lanchenlayer.facade.ProdutoFacade;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Scanner;

    @RestController
    public class ProdutoController {

        ProdutoFacade produtoFacade;

        public ProdutoController(ProdutoFacade produtoFacade) {
            this.produtoFacade = produtoFacade;
        }

    @GetMapping("/buscarProdutos")
    public ResponseEntity<ArrayList<Produto>> buscarTodos() {

        ArrayList<Produto> produtos = produtoFacade.buscarTodos();

        return ResponseEntity.ok(produtos);
    }

    @GetMapping("/buscarProduto/{id}")
    public ResponseEntity<Produto> buscarPorId(@PathVariable int id) {

        Produto produto = produtoFacade.buscarPorId(id);
        if (produto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(produto);
    }
}
