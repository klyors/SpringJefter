package com.lanchenlayer.Rest;

import com.lanchenlayer.entities.Produto;
import com.lanchenlayer.facade.ProdutoFacade;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.awt.color.ProfileDataException;
import java.time.Period;
import java.util.ArrayList;
import java.util.Properties;

@RestController
public class Rest {

    ProdutoFacade produtoFacade;

    @GetMapping("/CriarProdutos")
    public ResponseEntity<ArrayList<Produto>> buscarLivros() {
        Produto produto1 = new Produto(1, "Biblia", 10, "1");
        Produto produto2 = new Produto(2, "Imitação de Cristo", 11, "2");

        ArrayList<Produto> produtos = new ArrayList<Produto>();
        produtos.add(produto1);
        produtos.add(produto2);

        return ResponseEntity.ok(produtos);
    }

    @GetMapping("/buscarProdutos")
    public ResponseEntity<ArrayList<Produto>> buscarProduto() {

        ArrayList<Produto> produtos = produtoFacade.buscarTodos();

        return ResponseEntity.ok(produtos);
    }

    @GetMapping("/buscarPorId{id}")
    public ResponseEntity<Produto> buscarPorId(@PathVariable int id) {

        Produto produto = produtoFacade.buscarPorId(id);

        return ResponseEntity.ok(produto);
    }
}

